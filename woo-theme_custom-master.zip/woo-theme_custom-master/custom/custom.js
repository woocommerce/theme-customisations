jQuery(document).ready(function($){
	// Custom jQuery goes here
});
